//
//  OnboardView.swift
//  TabViewBugTest
//
//  Created by Ufuk Köşker on 25.03.2021.
//

import SwiftUI

struct OnboardView: View {
    @State var isLogin: Bool = false
    var body: some View {
        
        Button(action: {self.isLogin = true}) {
            Text("Login")
        }
        .fullScreenCover(isPresented: self.$isLogin) {
            ContentView()
        }
    }
}

struct OnboardView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardView()
    }
}
