//
//  ContentView.swift
//  TabViewBugTest
//
//  Created by Ufuk Köşker on 25.03.2021.
//

import SwiftUI

struct ContentView: View {
    //MARK: - Application Follow
    //1 - After the user logs on to the onBoardingView page, they are directed to ContentView with fullScreenCover.
    //2 - ContentView page contains objects in TabView that are repeated with ForEach. Clicking on these objects will take you to the DetailView page.
    //3 - However, Navigation repeats itself several times after clicking the object.
    @State var selected: String = ""
    var items: [String] = ["1","2","3","4","5","6","7","8","9","10"]
    var body: some View {
        NavigationView {
            TabView(selection: $selected) {
                ForEach(items, id: \.self) { item in
                    NavigationLink(
                        destination: DetailView(),
                        label: {
                            Text(item)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.orange)
                                .cornerRadius(10)
                        })
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
